
export * from "/static/node_modules/@solana/web3.js/lib/index.iife.js";

import {
    WalletAdapterNetwork, BaseMessageSignerWalletAdapter, WalletReadyState
} from '/static/node_modules/@solana/wallet-adapter-base/lib/esm/index.js';


import {PhantomWalletAdapter} from '/static/node_modules/@solana/wallet-adapter-phantom/lib/esm/index.js';

export {
    BaseMessageSignerWalletAdapter,
    WalletReadyState,
    WalletAdapterNetwork,
    PhantomWalletAdapter
}
